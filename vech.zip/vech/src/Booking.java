
import java.io.IOException;
import java.util.*;
import java.text.SimpleDateFormat;
import java.io.PrintWriter;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;



/**

 * Servlet implementation class Booking

 */

public class Booking extends HttpServlet {

 private static final long serialVersionUID = 1L;



  /**

   * @see HttpServlet#HttpServlet()

   */

  public Booking() {

    super();

    // TODO Auto-generated constructor stub

  }



 /**

 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)

 */

 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 // TODO Auto-generated method stub

 response.getWriter().append("Served at: ").append(request.getContextPath());

 }



 /**

 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)

 */

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 String a=request.getParameter("floor1");
 System.out.println("****"+a);
HttpSession session=request.getSession();
 PrintWriter out=response.getWriter();

 try{

 Class.forName("com.mysql.jdbc.Driver");

  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","root");
  PreparedStatement s=con.prepareStatement("select id from user where vehicle_no=?");
  s.setString(1,(String)session.getAttribute("vname"));
  ResultSet r=s.executeQuery();
  int id=0;
  while(r.next())
  {
	   id=r.getInt(1);
  }
  
  
  
  
  PreparedStatement stm=con.prepareStatement("insert into record(uid,date,intime) values(?,?,?)");
  Date d=new Date();
  SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy-HH:mm");
  String date=format.format(d);
  String s1[]=date.split("-");
  stm.setInt(1,id);
  stm.setString(2,s1[0]);
  stm.setString(3,s1[1]);
  stm.executeUpdate();
  PreparedStatement s2=con.prepareStatement("update parking set status=?,uid=? where floor=? and p_no=? ");
 s2.setInt(1,1);
 s2.setInt(2,id);
 s2.setString(3,(String)session.getAttribute("floor"));
 s2.setInt(4,Integer.parseInt(a));
 s2.executeUpdate();
 response.sendRedirect("home.jsp");
 }

 catch(Exception e)

 {

  System.out.print(e);

 }



 }



}