

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.print.PrinterJobWrapper;

/**
 * Servlet implementation class AddPark
 */
public class AddPark extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddPark() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      try
	      {
	    	  PrintWriter out=response.getWriter();
		String floor=request.getParameter("floor");
		String no=request.getParameter("no");
		String price=request.getParameter("price");
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","root");
	     PreparedStatement stm=con.prepareStatement("select * from parking");
	     ResultSet rs=stm.executeQuery();
	     while(rs.next())
	     {
	    	 if(rs.getString(2).equalsIgnoreCase(floor) && rs.getInt(3)==Integer.parseInt(no))
	    	 {
	    		 out.println("<script type=\"text/javascript\">");
	    		   out.println("alert('Entry is already present');");
	    		   out.println("location='addpark.jsp';");
	    		   out.println("</script>");
	    		   response.sendRedirect("home.jsp");
	    	 }
	    	 
	    	 else
	    	 {
	    		
	    	 }
	     }
	     PreparedStatement st=con.prepareStatement("insert into parking(floor,p_no,price) values(?,?,?)");
 		st.setString(1,floor);
 		st.setInt(2,Integer.parseInt(no));
 		st.setInt(3,Integer.parseInt(price));
 		st.executeUpdate();
 		 out.println("<script type=\"text/javascript\">");
 		   out.println("alert('Parking sucessfully Added');");
 		   out.println("location='addpark.jsp';");
 		   out.println("</script>");
 		   response.sendRedirect("home.jsp");
	      }
	      catch(Exception e)
	      {
	    	  System.out.println(e);
	      }
	      
	  }

}
