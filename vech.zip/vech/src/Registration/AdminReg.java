package Registration;



import java.io.IOException;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;



import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;



public class AdminReg extends HttpServlet {

 private static final long serialVersionUID = 1L;



  public AdminReg() {

    super();

    // TODO Auto-generated constructor stub

  }





 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 // TODO Auto-generated method stub

 response.getWriter().append("Served at: ").append(request.getContextPath());

 }





 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 String name=request.getParameter("name1");
 String surname=request.getParameter("name2");
 String gender=request.getParameter("gender");
String dob=request.getParameter("dob");
String addr=request.getParameter("addr");
String zip=request.getParameter("zip");
String phone=request.getParameter("phone");
String email=request.getParameter("email");

 String pwd=request.getParameter("pwd");
 

 try

 {

  Class.forName("com.mysql.jdbc.Driver");

  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","root");

  PreparedStatement stm=con.prepareStatement("insert into user(name,surname,gender,email,dob,address,zip,phone,password,access) values(?,?,?,?,?,?,?,?,?,?)");

	  stm.setString(1,name);
	  stm.setString(2,surname);
	  stm.setString(3,gender);
	  stm.setString(4,email);
	  stm.setString(5,dob);
	  stm.setString(6,addr);
	  stm.setString(7,zip);
	  stm.setInt(8,Integer.parseInt(phone));
	  stm.setString(9, pwd);
	  stm.setInt(10, 0);
  int i=stm.executeUpdate();

  if(i>0)

  {

  response.sendRedirect("index.jsp");

  }

  else

  response.sendRedirect("reg.jsp");

 }

 catch(Exception e)

 {

  System.out.println(e);

 }



 }



}

