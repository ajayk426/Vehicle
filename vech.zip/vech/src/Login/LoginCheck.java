package Login;
import java.io.IOException;

import java.io.PrintWriter;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;



import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;



/**

 * Servlet implementation class LoginCheck

 */

public class LoginCheck extends HttpServlet {

 private static final long serialVersionUID = 1L;



  /**

   * @see HttpServlet#HttpServlet()

   */

  public LoginCheck() {

    super();

    // TODO Auto-generated constructor stub

  }



 /**

 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)

 */

 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 // TODO Auto-generated method stub

 response.getWriter().append("Served at: ").append(request.getContextPath());

 }



 /**

 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)

 */

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

 String uname=request.getParameter("uname");

 String pwd=request.getParameter("pwd");

 PrintWriter out = response.getWriter();

 int i=0;

 try

 {

  Class.forName("com.mysql.jdbc.Driver");

  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/vehicle","root","root");

   PreparedStatement stm=con.prepareStatement("select * from user where name=? and password=?");

   stm.setString(1,uname);

   stm.setString(2,pwd);

   ResultSet rs=stm.executeQuery();

   while(rs.next())

   {

    i++;

   }

   if(i==0)

   {

    out.println("<script type=\"text/javascript\">");

     out.println("alert('User or password incorrect');");

     out.println("location='login.jsp';");

     out.println("</script>");



   }

   else

    response.sendRedirect("home.jsp");

 }

 catch(Exception e)

 {

  System.out.println(e);

 }

 }



}

